"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { SavedScan } from "@/lib/indexeddb";
import { listScans } from "@/lib/indexeddb";

export default function HistoryPage() {
  const [scans, setScans] = useState<SavedScan[]>([]);

  useEffect(() => {
    listScans().then(setScans).catch(() => setScans([]));
  }, []);

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col gap-4 p-4">
      <h1 className="text-2xl font-semibold">Scan History</h1>
      <Link className="text-sm underline" href="/">
        Back to capture
      </Link>

      {scans.length === 0 ? <p className="text-sm text-zinc-600">No saved scans yet.</p> : null}
      <ul className="flex flex-col gap-3">
        {scans.map((scan) => (
          <li key={scan.localId} className="rounded-lg border border-zinc-300 p-3">
            <p className="text-sm">Saved: {new Date(scan.createdAt).toLocaleString()}</p>
            <p className="text-xs text-zinc-600">Job: {scan.sourceJobId}</p>
            <Link className="text-sm underline" href={`/scan/${scan.localId}`}>
              Open
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
