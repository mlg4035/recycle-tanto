"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ExportButtons } from "@/components/ExportButtons";
import { TableGrid } from "@/components/TableGrid";
import type { SavedScan } from "@/lib/indexeddb";
import { getScan, updateScanTable } from "@/lib/indexeddb";
import type { TableModel } from "@/lib/types";

export default function ScanDetailPage() {
  const params = useParams<{ localId: string }>();
  const localId = Number(params.localId);
  const [scan, setScan] = useState<SavedScan | null>(null);
  const [table, setTable] = useState<TableModel | null>(null);

  useEffect(() => {
    if (!Number.isFinite(localId)) return;
    getScan(localId).then((result) => {
      if (!result) return;
      setScan(result);
      setTable(result.tableModel);
    });
  }, [localId]);

  async function onTableChange(next: TableModel) {
    setTable(next);
    await updateScanTable(localId, next);
  }

  if (!scan || !table) {
    return (
      <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col gap-4 p-4">
        <h1 className="text-2xl font-semibold">Saved Scan</h1>
        <p className="text-sm text-zinc-600">Scan not found.</p>
        <Link className="underline" href="/history">
          Back to history
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col gap-4 p-4">
      <h1 className="text-2xl font-semibold">Saved Scan #{scan.localId}</h1>
      <p className="text-sm text-zinc-600">{new Date(scan.createdAt).toLocaleString()}</p>
      <div className="flex gap-4 text-sm">
        <Link className="underline" href="/">
          Capture
        </Link>
        <Link className="underline" href="/history">
          History
        </Link>
      </div>
      <TableGrid table={table} onChange={onTableChange} />
      <ExportButtons
        table={table}
        rawResultJson={scan.rawResultJson}
        baseFilename={`scan-${scan.localId}`}
      />
    </main>
  );
}
